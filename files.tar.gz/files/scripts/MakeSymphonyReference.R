
# Load packages
library(Seurat)
library(SeuratDisk)
library(ggplot2)
library(symphony)
library(harmony)
library(sparseMatrixStats)
library(Matrix)
library(irlba)
library(tidyr)
library(tidyverse)


# set future globals since we are working with a big file
options(future.globals.maxSize = 8000 * 1024^2)



# Define paths
nameofRef="/home/hbanduk/scMuscle_diet_v1-1.h5Seurat"

projpath="/home/hbanduk/scratch/Dilworth/Symphony_MusAtlas"

outputOrig="Output/scMuscleAttrs"

outputNew="Output/SymphonyOutput"

MusRef <-  LoadH5Seurat(nameofRef)



# Save original umap and pca embeddings 
#H3_umap_embeddings <- write.csv(as.data.frame(
#  Embeddings(MusRef, reduction="harmony")), 
#  file.path(projpath, outputOrig,  "Harmony_embeddings.csv"))

pca_embeddings <- MusRef@reductions$pca@cell.embeddings
#write.csv(as.data.frame(pca_embeddings), file.path(projpath, outputOrig,
#                                                   "MusRef_PCAembeds.csv"))


# Get MusRef_metadata
#MusRef_Metadata_ <- as.data.frame(MusRef@meta.data)
#write.csv(MusRef_Metadata_, file.path(projpath, outputOrig, 
#                                      "MusRef_Metadata.csv"))

MusRef_Metadata_ <- read.csv(file.path(projpath, outputOrig, 
                                       "MusRef_Metadata.csv"))
MusRef_Metadata_ <- MusRef_Metadata_ %>% 
  separate(X, into = c("sample", "barcode"), sep = "\\_(?!.*_)", remove = FALSE)
MusRef_Metadata <- MusRef_Metadata_ %>% 
  dplyr::select(X, barcode, sample, source, orig.ident, nCount_RNA, nFeature_RNA)
MusRef_Metadata <- column_to_rownames(MusRef_Metadata, var = "X")

print("finished extracting Metadata info")
head(MusRef_Metadata)




print("starting symphony tutorial")

### Following Symphony tutorial

## https://github.com/immunogenomics/symphony/blob/main/vignettes
## /pbmcs_tutorial.ipynb/

## Make "vargenes_means_sds"



# get normalized genes by cells matrix
ref_exp_full <- MusRef[["RNA"]]@data

# extract variable genes
Var_genes <- VariableFeatures(MusRef)
Var_genes <- as.data.frame(Var_genes)


# Subset the normalized matrix by Var_genes
ref_exp <- ref_exp_full[Var_genes$Var_genes, ]

# Calculate and save the mean and standard deviations for each gene
vargenes_means_sds = tibble(symbol = Var_genes$Var_genes, mean = Matrix::rowMeans(ref_exp))
vargenes_means_sds$stddev = rowSds(ref_exp)
head(vargenes_means_sds)



# Using vargene_means_sds to scale data using calculated gene means 
# and standard deviations

ref_exp_scaled = scaleDataWithStats(ref_exp, vargenes_means_sds$mean, 
                                    vargenes_means_sds$stddev, 1)



set.seed(0)
s = irlba(ref_exp_scaled, nv = 20)
Z_pca_ref = diag(s$d) %*% t(s$v) # [pcs by cells]
loadings = s$u

write.csv(Z_pca_ref, file.path(projpath, outputNew, "Z_pca_ref.csv"))




print ("....running Harmony")
# Run Harmony to integrate the reference cells
ref_harmObj = harmony::HarmonyMatrix(
  data_mat = t(Z_pca_ref),   # starting embedding (e.g. PCA, CCA) of cells
  meta_data = MusRef_Metadata,  # dataframe with cell metadata
  theta = c(2),              # cluster diversity enforcement
  vars_use = c('sample'),     # variable to integrate out
  nclust = 100,              # number of clusters in Harmony model
  max.iter.harmony = 10,     # max iterations of Harmony
  return_object = TRUE,      # set to TRUE to return the full Harmony object
  do_pca = FALSE             # do not recompute PCs
)
print ("finished running Harmony")

print ("....building symphony reference")
# Build Symphony reference
reference = buildReferenceFromHarmonyObj(
  ref_harmObj,            # output object from HarmonyMatrix()
  MusRef_Metadata,           # dataframe with cell metadata
  vargenes_means_sds,     # gene names, means, and std devs for scaling
  loadings,               # genes x PCs
  verbose = TRUE,         # display output?
  do_umap = TRUE,         # run UMAP and save UMAP model to file?
  save_uwot_path = file.path(projpath, outputNew, 'uwot_model_1') 
  # filepath to save UMAP model
)





saveRDS(reference, file.path(projpath, outputNew,'scMus_SymphonyRef.rds'))


